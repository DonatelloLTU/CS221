/**
 * Linked List class
 * @author Donatas Vasauskas
 * @version 2020-09-18.01
 */

public class SortedLinkedList implements SortedLinkedListADT
{

}
