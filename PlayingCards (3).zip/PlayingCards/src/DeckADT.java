public class DeckADT
{
public DeckADT()
{

}
public void shuffle()
{

}
public void draw()
{

}
public int getCards()
{

}

}
