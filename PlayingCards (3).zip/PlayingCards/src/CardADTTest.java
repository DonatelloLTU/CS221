import org.junit.Test;
import static org.junit.Assert.*;
import java.util.Arrays;
import java.util.Random;

public class CardADTTest extends CardADT
{

    CardADT cardADT = new CardADT();

    @Test
    public void setValueTest()
    {


    }
    @Test
    public void getValueTest()
    {

    }
    @Test
    public void setRankTest()
    {

    }
    @Test
    public void getRankTest()
    {

    }
    @Test
    public void setSuitTest()
    {

    }
    @Test
    public void getSuitTest()
    {

    }
    @Test
    public void toStringTest()
    {

    }


}
