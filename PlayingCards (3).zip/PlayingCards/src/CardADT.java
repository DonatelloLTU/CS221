import java.io.File;

public class CardADT {
    int suite;
    int value;
    int rank;
    File graphics;

    public CardADT ()
    {

    }
    public void show()
    {

    }
    public void setValue()
    {

    }
    public int getValue()
    {

    }
    public void setRank()
    {

    }
    public int getRank()
    {

    }
    public void setSuit()
    {

    }
    public int getSuit()
    {

    }
    public String toString()
    {

    }
}
