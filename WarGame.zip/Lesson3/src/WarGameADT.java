/**
 * WarGameADT
 */
public interface WarGameADT
{
    /**
     * This method will be main method of the game
     * @param args
     */
   public static void main(String[] args) {

    }
}
