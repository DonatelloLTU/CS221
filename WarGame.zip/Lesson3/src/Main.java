/**
 * @author Donatas Vasauskas
 * @version 2020-09-10.01
 */
public class Main
{
    public static void main(String[] args) {
        Deck deck = new Deck();
    }
}
